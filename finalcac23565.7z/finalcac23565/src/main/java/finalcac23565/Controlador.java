package finalcac23565;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import models.Usuario;
import infrastructure.persistence.*;
import infrastructure.persistence.memory.*;
import mappers.*;
public class Controlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IPersistence persistence = new MemoryRepositoryImpl();
	private ObjectMapper mapper;
    
    public Controlador() {
    	mapper = new MapperJson().getMapper();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ArrayList<Usuario> lista = persistence.listarUsuarios();
		mapper.writeValueAsString(lista);
		response.getWriter().write(lista.toString());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
		String nombre = request.getParameter("nombreInput");
		String apellido = request.getParameter("apellidoInput");
		String email = request.getParameter("emailInput");
		String tema = request.getParameter("temaInput");
		
		Usuario usuario = new Usuario (nombre, apellido, email, tema);
		
		persistence.guardar(usuario);
		//System.out.println(usuario);
		
		//response.getWriter().write(usuario.toString());
		
		//ObjectMapper mapper = new ObjectMapper();
		String usuarioJson = mapper.writeValueAsString(usuario);
		
		response.getWriter().write(usuarioJson);
		
		
		//System.out.println("Nombre: " + nombre +  " Apellido: " + apellido + " email: " + email + " Tema: " + tema);
	}

}
