package infrastructure.persistence.memory;

import java.util.ArrayList;

import infrastructure.persistence.IPersistence;
import models.Usuario;

public class MemoryRepositoryImpl implements IPersistence{
	
	public static ArrayList<Usuario> bdMemoria =new ArrayList<>();

	@Override
	public void guardar(Usuario newUsuario) {
		if(MemoryRepositoryImpl.bdMemoria.add(newUsuario));
		System.out.println("El usuario " + newUsuario.getNombre() + "-"  + newUsuario.getApellido() + " fue grabado exitosamente con el id: " + newUsuario.getId() + " idUUID: " + newUsuario.getIdUsuario());
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Usuario> listarUsuarios() {
		
		return MemoryRepositoryImpl.bdMemoria;
	}

	@Override
	public Usuario getUsuarioPorId(String Id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario update(String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String Id) {
		// TODO Auto-generated method stub
		
	}

}
